# Service-Discovery-Eureka-Server-DIO
eureka server  para live coding ministrado na DIO

As seguintes aplicações estão configuradas para serem eureka client:

[Order service](https://github.com/Kamilahsantos/Order-Eureka-Client-Service)

[Delivery Service](https://github.com/Kamilahsantos/Delivery-Eureka-Client-Service)

[Customer Service - (com spring boot admin)](https://github.com/Kamilahsantos/Customer-Eureka-Client-Service)
