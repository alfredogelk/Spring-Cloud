# Order-Eureka-Client-Service

Order service do livecoding da DIO

[eureka server da aplicaçao](https://github.com/Kamilahsantos/Service-Discovery-Eureka-Server-DIO)

